<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::post('/enviar', function (Illuminate\Http\Request $request) {

    $produtos = new App\Models\Produto();
    $produtos->CodigoProduto = $request->get('CodigoProduto');
    $produtos->NomeProduto = $request->get('NomeProduto');
    $produtos->Categoria =$request->get('Categoria');
    $produtos->PrecoUnitario = $request->get('PrecoUnitario');
    $produtos->Descricao = $request->get('Descricao');

    $produtos->save();

    echo "Sua mensagem foi armazenada com sucesso! Código: " . $produtos->id;
});
    
Route::get('/lista', function() {
    return view ('lista', array('produtos' => App\Models\Produto::all()));
});

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Trabalho Prático de Avaliação César</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css">
</head>

<body>
    <div class="container">
        <h1>Trabalho Prático de Avaliação César</h1>
        <hr />
        <form action="/enviar" method="POST">
            <input type="hidden" name="_token" value="{{ csrf_token()}}">
            <div class="form-group">
                <label for="nome">Código do Produto</label>
                <input type="text" id="CodigoProduto" name="CodigoProduto" class="form-control" placeholder="Código do Prduto">
            </div>


                <div class="form-group">
                    <label for="nome">Nome do Produto</label>
                    <input type="text" id="NomeProduto" name="NomeProduto" class="form-control" placeholder="Nome do Produto">
                </div>


                    <div class="form-group">
                        <label for="nome">Categoria</label>
                        <input type="text" id="Categoria" name="Categoria" class="form-control" placeholder="Categoria">
                    </div>


                        <div class="form-group">
                            <label for="nome">Preço Unitário</label>
                            <input type="text" id="PrecoUnitario" name="PrecoUnitario" class="form-control" placeholder="Preço Unitário">
                        </div>
                        <div class="form-group">
                            <label for="descricao">Descrição</label>
                            <div class="form-group">
                                <textarea name="Descricao" id="Descricao" class="form-control" placeholder="Digite a descrição do produto" cols="30" rows="10"></textarea>
                            </div>
                            <button type="submit" class="btn btn-dark">Enviar</button>
                    </form>
    </div>
</body>

</html>